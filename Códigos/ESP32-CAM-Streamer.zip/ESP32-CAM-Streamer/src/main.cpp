#include "Arduino.h"
#include "esp_camera.h"
#include "WiFi.h"
#include "esp_http_server.h"

// ===== PINES PARA AI THINKER ESP32-CAM =====
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ===== CREDENCIALES WiFi (CÁMBIALAS POR LAS TUYAS) =====
const char* ssid     = "POCO X6 Pro 5G";
const char* password = "12345678";

// ===== CONFIGURACIÓN STREAM =====
#define PART_BOUNDARY "123456789000000000000987654321"
static const char* _STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* _STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* _STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

httpd_handle_t camera_httpd = NULL;

// ==================== HANDLER STREAM ====================
static esp_err_t stream_handler(httpd_req_t *req) {
    camera_fb_t *fb = NULL;
    esp_err_t res = ESP_OK;
    char part_buf[64];
    
    res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
    if (res != ESP_OK) return res;
    
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache");
    
    Serial.println("📹 Cliente conectado al stream");
    
    while (true) {
        fb = esp_camera_fb_get();
        if (!fb) {
            Serial.println("❌ Error obteniendo frame");
            break;
        }
        
        res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
        if (res != ESP_OK) { 
            esp_camera_fb_return(fb); 
            break; 
        }
        
        size_t hlen = snprintf(part_buf, sizeof(part_buf), _STREAM_PART, fb->len);
        res = httpd_resp_send_chunk(req, part_buf, hlen);
        if (res != ESP_OK) { 
            esp_camera_fb_return(fb); 
            break; 
        }
        
        res = httpd_resp_send_chunk(req, (const char*)fb->buf, fb->len);
        esp_camera_fb_return(fb);
        
        if (res != ESP_OK) break;
        
        delay(30);  // ~30 fps
    }
    
    Serial.println("📹 Cliente desconectado");
    return res;
}

// ==================== HANDLER FOTO ====================
static esp_err_t capture_handler(httpd_req_t *req) {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }
    
    httpd_resp_set_type(req, "image/jpeg");
    httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=capture.jpg");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    
    esp_err_t res = httpd_resp_send(req, (const char*)fb->buf, fb->len);
    esp_camera_fb_return(fb);
    return res;
}

// ==================== PÁGINA PRINCIPAL ====================
static esp_err_t index_handler(httpd_req_t *req) {
    String ip = WiFi.localIP().toString();
    String html = "<!DOCTYPE html><html>"
        "<head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>"
        "<title>ESP32-CAM</title>"
        "<style>"
        "body{background:#0a0a0a;color:#00e5ff;font-family:monospace;text-align:center;padding:20px}"
        "h1{font-size:1.8rem}"
        "#sc{max-width:800px;margin:0 auto;border:2px solid #00e5ff;border-radius:8px;background:#000}"
        "#stream{width:100%;display:block}"
        "button{background:transparent;border:1px solid #00e5ff;color:#00e5ff;padding:10px 20px;margin:5px;"
        "font-family:monospace;font-size:1rem;cursor:pointer;border-radius:4px}"
        "button:hover{background:#00e5ff;color:#000}"
        "</style>"
        "</head><body>"
        "<h1>ESP32-CAM STREAM</h1>"
        "<div id='sc'><img id='stream' src='/stream'></div>"
        "<div><button onclick='reloadStream()'>🔄 RECARGAR</button>"
        "<button onclick='takePhoto()'>📸 FOTO</button></div>"
        "<script>"
        "function reloadStream(){document.getElementById('stream').src='/stream?'+Date.now()}"
        "function takePhoto(){window.open('/capture','_blank')}"
        "</script>"
        "</body></html>";
    
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, html.c_str(), html.length());
}

// ==================== CONFIGURAR CÁMARA ====================
bool initCamera() {
    // Power cycle completo para asegurar que la cámara arranca limpia
    pinMode(PWDN_GPIO_NUM, OUTPUT);
    digitalWrite(PWDN_GPIO_NUM, HIGH);
    delay(100);
    digitalWrite(PWDN_GPIO_NUM, LOW);
    delay(100);
    
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = 8000000;      // 8MHz - más estable que 10MHz o 20MHz
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_QVGA;  // 320x240 - fluido y estable
    config.jpeg_quality = 12;
    config.fb_count = 1;
    
    Serial.println("Inicializando cámara...");
    esp_err_t err = esp_camera_init(&config);
    
    if (err != ESP_OK) {
        Serial.printf("❌ Error al iniciar cámara: 0x%x\n", err);
        return false;
    }
    
    Serial.println("✅ Cámara inicializada correctamente");
    
    // ===== VOLTEAR IMAGEN 180 GRADOS =====
    sensor_t *s = esp_camera_sensor_get();
    if (s) {
        s->set_hmirror(s, 1);  // Espejo horizontal (voltear izquierda-derecha)
        s->set_vflip(s, 1);     // Volteo vertical (arriba-abajo)
        Serial.println("✅ Imagen volteada 180°");
    } else {
        Serial.println("⚠️ No se pudo obtener el sensor para voltear imagen");
    }
    
    // Probar captura para verificar que todo funciona
    camera_fb_t *test = esp_camera_fb_get();
    if (test) {
        Serial.printf("✅ Prueba de captura exitosa: %zu bytes\n", test->len);
        esp_camera_fb_return(test);
        return true;
    }
    
    Serial.println("❌ La cámara no puede capturar imágenes");
    return false;
}

// ==================== INICIAR SERVIDOR ====================
void startServer() {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.lru_purge_enable = true;
    
    if (httpd_start(&camera_httpd, &config) == ESP_OK) {
        httpd_uri_t uris[] = {
            { "/", HTTP_GET, index_handler, NULL },
            { "/capture", HTTP_GET, capture_handler, NULL },
            { "/stream", HTTP_GET, stream_handler, NULL }
        };
        for (int i = 0; i < 3; i++) {
            httpd_register_uri_handler(camera_httpd, &uris[i]);
        }
        Serial.println("✅ Servidor HTTP iniciado en puerto 80");
    } else {
        Serial.println("❌ Error al iniciar el servidor HTTP");
    }
}

// ==================== SETUP ====================
void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n========================================");
    Serial.println("       ESP32-CAM STREAMER FINAL");
    Serial.println("========================================\n");
    
    // 1. PRIMERO: Inicializar la cámara
    if (!initCamera()) {
        Serial.println("No se pudo iniciar la cámara - reiniciando en 5 segundos...");
        delay(5000);
        ESP.restart();
        return;
    }
    
    // 2. SEGUNDO: Conectar al WiFi
    WiFi.begin(ssid, password);
    WiFi.setSleep(false);
    Serial.print("Conectando a WiFi");
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 40) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("\n❌ No se pudo conectar al WiFi");
        Serial.println("Verifica el nombre y contraseña de tu red");
        return;
    }
    
    Serial.println("\n✅ WiFi conectado correctamente!");
    Serial.print("📡 Dirección IP: ");
    Serial.println(WiFi.localIP());
    
    // 3. TERCERO: Iniciar el servidor web
    startServer();
    
    Serial.println("\n========================================");
    Serial.print("🌐 ABRE ESTA DIRECCIÓN EN TU NAVEGADOR: http://");
    Serial.println(WiFi.localIP());
    Serial.println("========================================\n");
    Serial.println("📹 Para ver el stream directo en VLC:");
    Serial.print("   http://");
    Serial.print(WiFi.localIP());
    Serial.println("/stream");
    Serial.println("========================================\n");
}

// ==================== LOOP ====================
void loop() {
    // El servidor corre en segundo plano, solo mantenemos el ESP32 activo
    delay(10000);
    
    // Mostrar estado del WiFi cada 30 segundos
    static unsigned long lastStatus = 0;
    if (millis() - lastStatus > 30000) {
        lastStatus = millis();
        Serial.printf("📡 WiFi: %s | RSSI: %d dBm\n", 
            WiFi.status() == WL_CONNECTED ? "Conectado" : "Desconectado", 
            WiFi.RSSI());
    }
}